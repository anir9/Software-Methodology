/**
 * This is an International class that extends the Student class.
 * This class manages tuition information for International Student objects. 
 * @author Aniqa Rahim, Christopher Rosenberger
 */
public class International extends Student{
    public static int MIN_CREDIT_HOURS = 9;
    private int COST_PER_CREDIT = 945;
    private int INTERNATIONAL_STUDENT_FEE = 350;
    private boolean exchange;
    
    /**
     * This is a basic International Student constructor that creates International Student Objects.  
     * @param fname Student's first name
     * @param lname Student's last name
     * @param credit Total number of credit hours the student is enrolled in
     * @param exchange The International Student's exchange status. The boolean is true if the student is an exchange student. It is false otherwise. 
     */
    public International(String fname, String lname, int credit, boolean exchange) {
        super(fname, lname, credit);
        this.exchange = exchange;
    }
    
    /**
     * This is a method that returns a string with the International Student's tuition information.
     * Calls the toString() method of the Student superclass.
     * @return Returns a string with the International Student's information, including the exchange status of the student, and the final tuition due
     */
    public String toString() {
        return super.toString() + (exchange ? "exchange,":"not-exchange,") + " tuition due: $" + tuitionDue();
    }
    
    /**
     * This is a method that calculates the tuition due for an International Student.
     * @return Returns the total tuition due for the International Student
     */
    public int tuitionDue() {
        int billedCredits = Math.min(credit, MAX_BILLED_CREDITS);
        int fee = credit >= FULL_TIME_CREDITS ? FULL_TIME_FEE:PART_TIME_FEE;
        return fee + INTERNATIONAL_STUDENT_FEE + (exchange ? 0:COST_PER_CREDIT * billedCredits);
    }
    
    /** 
     * This is the main method where we test the methods in the International subclass.
     * @param args Standard Input
     */
    public static void main(String args[]) {
        International in = new International("David", "Lee", 12, false);
        System.out.println(in);
        International in2 = new International("Joe", "Kim", 12, true);
        System.out.println(in2);
    }
}
