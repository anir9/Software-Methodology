/**
 * This is an abstract Student class that implements the Comparable Interface. 
 * @author Aniqa Rahim and Christopher Rosenberger
 */
public abstract class Student implements Comparable {
    protected int MAX_BILLED_CREDITS = 15;
    protected int FULL_TIME_CREDITS = 12;
    protected int PART_TIME_FEE = 846;
    protected int FULL_TIME_FEE = 1441;
	private String fname;
    private String lname;
    protected int credit;
    
    /**
     * This is a basic Student constructor that defines a Student Object.
     * @param fname Student's first name
     * @param lname Student's last name
     * @param credit Total number of credit hours the student is enrolled in 
     */
    public Student(String fname, String lname, int credit) {
        this.fname = fname;
        this.lname = lname;
        this.credit = credit;
    }
   
    /**
     * This is a method that compares one Student Object with an instance of another. 
     * We must implement compareTo method because Student class implements the Comparable Interface.
     * @param obj Student Object
     * @return Returns -1 if this fname or lname is < obj�s. Returns 1 if this fname or lname is > obj�s. Returns 0 if fname and lname of the two students are equal.  
     */
    public int compareTo(Object obj) {
        Student other = (Student)obj;    //Create Student object "other"
        if(lname.compareToIgnoreCase(other.lname) < 0) {    //Return -1 if this lname is < obj�s
            return -1;
        } else if(lname.compareToIgnoreCase(other.lname) > 0) {    //Return 1 if this lname is > obj�s
            return 1;
        } else {
            if(fname.compareToIgnoreCase(other.fname) < 0) {    //Return -1 if this fname is < obj�s
                return -1;
            } else if(fname.compareToIgnoreCase(other.fname) > 0) {    //Return 1 if this fname and lname is > obj�s
                return 1;
            } else {    //Return 0 if fname and lname of the two students are equal
                return 0;
            }
        }
    }
    
    /**
     * This method returns a string with fname, lname and credit hours. 
     * Subclasses will be using this method.
     * @return Returns string with the Student's full name and the number of credit hours they are enrolled in   
     */
    public String toString() {
        return fname + " " + lname + "," + " credits: " + credit + ", ";
    }
    
    /**
     * This is an abstract method that computes the tuition due by the student.
     * @return Returns the tuition due by the student
     */
    public abstract int tuitionDue();
}
