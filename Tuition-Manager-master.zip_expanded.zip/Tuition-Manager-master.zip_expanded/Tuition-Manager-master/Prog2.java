/** 
 * This is the main method in class Prog2 that calls the run() method in the TuitionManager class.
 * @author  Aniqa Rahim afr64, Christopher Rosenberger cor9
 */
public class Prog2 {
    public static void main(String [] args) {
        new TuitionManager().run();
    } 
}
