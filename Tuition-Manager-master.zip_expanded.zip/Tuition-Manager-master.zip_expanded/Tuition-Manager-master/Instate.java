/**
 * This is an Instate class that extends the Student class.
 * This class manages tuition information for Instate Student objects. 
 * @author Aniqa Rahim, Christopher Rosenberger
 */
public class Instate extends Student{
    private int COST_PER_CREDIT = 433;
    private int funds;
    
    /**
     * This is a basic Instate Student constructor that creates Instate Student Objects.  
     * @param fname Student's first name
     * @param lname Student's last name
     * @param credit Total number of credit hours the student is enrolled in
     * @param funds Total dollar amount of funds given towards the student's tuition
     */
    public Instate(String fname, String lname, int credit, int funds) {
        super(fname, lname, credit);
        this.funds = funds;
    }
    
    /**
     * This is a method that returns a string with the Instate Student's tuition information.
     * Calls the toString() method of the Student superclass.
     * @return Returns a string with the Instate Student's information, including the amount of funding they receive, and the final tuition due 
     */
    public String toString() {
        return super.toString() + "funds: " + funds + ", tuition due: $" + tuitionDue(); 	
    }
    
    /**
     * This is a method that calculates the tuition due for an Instate Student.
     * @return Returns the total tuition due for the Instate Student
     */
    public int tuitionDue() {
        int billedCredits = Math.min(credit, MAX_BILLED_CREDITS);
        int fundsAvailable = credit >= FULL_TIME_CREDITS ? funds:0;
        int fee = credit >= FULL_TIME_CREDITS ? FULL_TIME_FEE:PART_TIME_FEE;
        return COST_PER_CREDIT * billedCredits + fee - fundsAvailable;
    }
    
    /** 
     * This is the main method where we test the methods in the Instate subclass.
     * @param args Standard Input 
     */
    public static void main(String args[]) {
        Instate is = new Instate("Peter", "Parker", 12, 0);
        System.out.println(is);
        Instate is2 = new Instate("Wilson", "Long", 6, 1000);
        System.out.println(is2);
    }
}
