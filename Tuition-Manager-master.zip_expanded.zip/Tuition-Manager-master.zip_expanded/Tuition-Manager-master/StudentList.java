/**
 * This is a StudentList class that manages a collection of Students enrolled in the university
 * @author Aniqa Rahim, Christopher Rosenberger
 */
public class StudentList {
    private final int NOT_FOUND = -1;
    private final int GROW_SIZE = 2;
    private final int INITIAL_SIZE = 10;
    private Student[] students;
    private int numMembers;
    
    /**
     * This is the default constructor for the StudentList class.
     */
    public StudentList() {
        students = new Student[INITIAL_SIZE];
    }
    
    /**
     * This method increases the size of the student array to make room for additional Students.  
     */
    private void grow() {
        Student[] temp = new Student[numMembers * GROW_SIZE];   // Creates a new Student array that's size is larger by a factor of GROW_SIZE. 
        for(int i = 0; i < numMembers; i++) {
            temp[i] = students[i];
        }
        students = temp;
    }
    
    /**
     * This method finds the index position of a given Student in the student array.
     * @param s A Student Object
     * @return Returns the current index of s in the student array. Returns NOT_FOUND if s is not found in the array.
     */
    private int find(Student s) {
        for(int i = 0; i < numMembers; i++) {
            if(students[i].compareTo(s) == 0) {
                return i;
            }
        }
        return NOT_FOUND;
    }
    
    /**
     * This method adds a student to the list.
     * It calls grow() if there is no space on the student array.
     * It calls find() to find the index position of a duplicate Student in the array.
     * @param s A Student Object
     * @return Returns false when a student is already on the list. Returns true when a student is successfully added to the list. 
     */
    public boolean add(Student s) {
        if(find(s) != NOT_FOUND) {
            return false;
        } else if(numMembers == students.length) {
            grow();
        }
        students[numMembers++] = s;
        return true;
    }
    
    /**
     * This method removes a student from the list.
     * It calls find() to find the index position of the team member to be removed.
     * @param s A Student Object
     * @return Returns false when a student is not on the list. Returns true when a student is successfully removed from the list.
     */
    public boolean remove(Student s)	{
        int removeLocation = find(s);
        if(removeLocation == NOT_FOUND) {
            return false;
        }
        students[removeLocation] = students[numMembers - 1];   // Replaces to-be-removed student with the last student in the array.
        students[--numMembers] = null;   // Sets pointer of last student to null. Decrements numMembers.
        return true;
    } 
    
    /**
     * This method checks if the StudentList is empty.
     * @return Returns true if there are no students in the list. Otherwise, returns false.
     */
    public boolean isEmpty() {
        return numMembers == 0;
    }
    
    /**
     * This method prints a list of current students on the list.
     * It prints a confirmation message if the student list has no students in it.
     */
    public void print() {
        for(Student s: students) {
            if(s == null) {
                return;    //End of students
            }
            System.out.println(s);
        }
    }
}
