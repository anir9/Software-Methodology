import java.util.Scanner;

/** 
 * This class allows the user to manage an instance of the StudentList class through the console.
 * @author Aniqa Rahim, Christopher Rosenberger
 */
public class TuitionManager {
    Scanner stdin;
    StudentList students;
    
    /**
     * This method uses the Scanner class to read the standard input to create and manage a new StudentList.
     * Warns user of the use of any invalid commands.
     */
    public void run() {
        stdin = new Scanner(System.in);
        students = new StudentList();
        boolean done = false;
        while(!done) {
            String command = stdin.next();
            switch(command.charAt(0)) {   
                case 'I': case 'O': case 'N':
                    add(command.charAt(0));  
                    break; 
                case 'R': 
                    remove();  
                    break;
                case 'P': 
                    print();
                    break;
                case 'Q': 
                    System.out.println("Program terminated");
                    done = true;
                    break;
                default:    //Warns user of invalid command.   
                    System.out.println("Command '" + command.charAt(0) + "' not supported!");
                    stdin.nextLine();
            }  
        }
        stdin.close();
    }
    
    /** 
     * This method creates and adds a student along with their information, to the list.
     * It uses the scanner class to read the student's information from the standard input. 
     * It checks if the number of credit hours is valid.
     * It checks if the funding amount is valid.  
     * @param studentType The type of student: I = Instate, O = Outstate, N = International
     */
    private void add(char studentType) {
        String fname = stdin.next();
        String lname = stdin.next();
        int credit = stdin.nextInt();
        boolean valid = false;

        if(credit <= 0) {    //Checks if the number of credit hours is positive
            System.out.println("Invalid number of credits.");
            return;
        }
        switch(studentType) {
            case 'I':
                int funds = stdin.nextInt();
                if(funds <= 0) {    //Checks if the funding amount is valid
                    System.out.println("Invalid funding amount.");
                    return;
                } else if(credit < 12) {    //Checks if student is eligible for funding based on the number of credit hours
                    System.out.println("Part time students are not eligible for funding.");
                }
                valid = students.add(new Instate(fname,lname,credit,funds));
                break;
            case 'O':
                boolean tristate = stdin.next() == "T" ? true:false;
                valid = students.add(new Outstate(fname,lname,credit,tristate));
                break;
            case 'N':
                if(credit < 9) {    //Checks if the International Student is taking at least 9 credit hours
                    stdin.next();
                	System.out.println("Invalid number of credits.");
                    return;
                }
                boolean exchange = stdin.next() == "T" ? true:false;
                valid = students.add(new International(fname,lname,credit,exchange));
                break;
        }
        if(!valid) {
            System.out.println("Student already on the list.");
        } else {
            System.out.println("Student successfully added to the list.");
        }
    }  

    /**
     * This method removes an existing student from the list.
     * It uses the scanner class to read the student's first and last name from the standard input.
     * It prints a confirmation message when the student is successfully removed from the list.
     * It prints a warning message when the student is not on list. 
     * It calls isEmpty() to check if the student list is empty.
     * @return - Returns if the student list is empty.
     */
    private void remove() {
        String fname = stdin.next();
        String lname = stdin.next();
        if(students.isEmpty()) {    //Calls isEmpty()
            System.out.println("There are no students on the list.");
            return;
        }
        if(!students.remove(new Instate(fname,lname,0,0))) {
            System.out.println("Student not on the list.");
        } else {
            System.out.println("Student removed from list.");
        }
    }

    /**
     * This method prints a list of currently enrolled students.
     * It calls isEmpty() to check if there are no students on the list. Warns the user, if so.
     */
    private void print() {
        if(students.isEmpty()) {
            System.out.println("There are no students on the list.");
        } else {
            students.print();
        }
    }
}