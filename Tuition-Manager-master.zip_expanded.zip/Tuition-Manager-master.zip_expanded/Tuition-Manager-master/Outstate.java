/**
 * This is an Outstate class that extends the Student class.
 * This class manages tuition information for Outstate Student objects. 
 * @author Aniqa Rahim, Christopher Rosenberger
 */
public class Outstate extends Student{
    private int DISCOUNT = 200;
    private int COST_PER_CREDIT = 756;
    private boolean tristate;
    
    /**
     * This is a basic Outstate Student constructor that creates Outstate Student Objects.
     * @param fname Student's first name
     * @param lname Student's last name
     * @param credit Total number of credit hours the student is enrolled in
     * @param tristate The Outstate Student's tristate status. The boolean is true if the student lives in the tristate area. It is false otherwise.
     */
    public Outstate(String fname, String lname, int credit, boolean tristate) {
        super(fname, lname, credit);
        this.tristate = tristate;
    }
    
    /**
     * This is a method that returns a string with the Outstate Student's tuition information.
     * Calls the toString() method of the Student superclass.
     * @return Returns a string with the Outstate Student's information, including the tristate status of the student, and the final tuition due
     */
    public String toString() {
        return super.toString() + (tristate ? "tristate,":"not-tristate,") + " tuition due: $" + tuitionDue();
    }
    
    /**
     * This is a method that calculates the tuition due for an Outstate Student.
     * @return Returns the total tuition due for the Outstate Student
     */
    public int tuitionDue() {
        int billedCredits = Math.min(credit, MAX_BILLED_CREDITS);
        int fundsAvailable = tristate ? DISCOUNT*billedCredits:0;
        int fee = credit >= FULL_TIME_CREDITS ? FULL_TIME_FEE:PART_TIME_FEE;
        return COST_PER_CREDIT * billedCredits + fee - fundsAvailable;
    }
    
    /** 
     * This is the main method where we test the methods in the Outstate subclass.
     * @param args Standard Input
     */
    public static void main(String args[]) {
        Outstate os = new Outstate("May", "Anderson", 17, false);
        System.out.println(os);
        Outstate os2 = new Outstate("Lauren", "Brown", 17, true);
        System.out.println(os2);
    }
}
