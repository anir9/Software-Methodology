/**
  
 @author  
 */
public class Prog1 {
   public static void main(String [] args) {
      new ProjectManager().run();
   } 
}
