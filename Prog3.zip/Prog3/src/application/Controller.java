package application;

import tuitionManager.*;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.stage.Stage;

/**
 * Controller class related to the GUI used to graphically manipulate a list of Students.  Defines the onActivation properties of various GUI components.
 * 
 * @author Aniqa Rahim, Christopher Rosenberger
 */
public class Controller {
    
    private static final String ON_START = "Tuition Manager started successfully\n\n";
    
    private static final String ADD_SUCCESS = "Student successfully added to the list\n\n";
    private static final String REMOVE_SUCCESS = "Student successfully removed from the list\n\n";
    private static final String ADD_FAILURE = "Student specified was unable to be added to list\n\n";
    private static final String REMOVE_FAILURE = "Student specified was unable to be removed from list\n\n";
    
    private static final String NO_FIRST_NAME = "Error: No first name specified for student\n";
    private static final String NO_LAST_NAME = "Error: No last name specified for student\n";
    
    private static final String NO_CREDITS = "Error: number of credits not specified\n";
    private static final String CREDITS_NOT_NUMBER = "Error: credits specified is not a number\n";
    private static final String CREDITS_INVALID = "Error: number of credits must be greater than zero\n";
    private static final String CREDITS_INVALID_INTERNATIONAL = "Error: International students must take at least " + International.MIN_CREDIT_HOURS + " credit hours\n";
    
    private static final String NO_FUNDS = "Error: amount of funding not specified\n";
    private static final String FUNDS_NOT_NUMBER = "Error: amount of funding specified is not an integer\n";
    private static final String FUNDS_INVALID = "Error: invalid amount of funding\n";
    private static final String PART_TIME_FUNDS_WARNING = "Warning: part time students are not eligible for funding\n";
    
    private static final String STUDENT_ALREADY_PRESENT = "Error: student already on list\n";
    private static final String STUDENT_NOT_FOUND = "Error: student specified not on list\n";
    

    @FXML
    private Label fnameLabel;
    @FXML
    private TextField fnameTF;
    @FXML
    private Label lnameLabel;
    @FXML
    private TextField lnameTF;
    @FXML
    private Label creditslabel;
    @FXML
    private TextField creditsTF;
    @FXML
    private Label studentTypeLabel;
    @FXML
    private RadioButton instateRB;
    @FXML
    private RadioButton outstateRB;
    @FXML
    private RadioButton internationalRB;
    @FXML
    private CheckBox instateCB;
    @FXML
    private CheckBox outstateCB;
    @FXML
    private CheckBox internationalCB;
    @FXML
    private TextField instateTF;
    @FXML
    private TextArea outputTA;
    @FXML
    private Button addButton;
    @FXML
    private Button removeButton;
    @FXML
    private Button printButton;

    private StudentList students = new StudentList();
    ToggleGroup studentTypeRG = new ToggleGroup();

    /**
     * Sets initial values for the specified Stage used to manage a list of students graphically
     * @param primaryStage Stage used to manage a list of students graphically
     */
    public void start(Stage primaryStage) {
        instateRB.setToggleGroup(studentTypeRG);
        outstateRB.setToggleGroup(studentTypeRG);
        internationalRB.setToggleGroup(studentTypeRG);
        studentTypeRG.selectToggle(instateRB);
        instateTF.setDisable(true);
        outstateCB.setDisable(true);
        internationalCB.setDisable(true);
        outputTA.setEditable(false);
        outputTA.setText(ON_START);

        fnameTF.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\sa-zA-Z*")) {
                fnameTF.setText(newValue.replaceAll("[^\\sa-zA-Z]", ""));
            }
        });
        lnameTF.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\sa-zA-Z*")) {
                lnameTF.setText(newValue.replaceAll("[^\\sa-zA-Z]", ""));
            }
        });
    }

    /**
     * Sets the properties for instateRB when activated
     * Enables instateCB and disables the others
     */
    @FXML
    private void instateRBClick() {
        instateCB.setDisable(false);
        outstateCB.setDisable(true);
        outstateCB.setSelected(false);
        internationalCB.setDisable(true);
        internationalCB.setSelected(false);
    }

    /**
     * Sets the properties for outstateRB when activated
     * Enables outstateCB and disables the others
     */
    @FXML
    private void outstateRBClick() {
        instateCB.setDisable(true);
        instateCB.setSelected(false);
        instateTF.setDisable(true);
        outstateCB.setDisable(false);
        internationalCB.setDisable(true);
        internationalCB.setSelected(false);
    }

    /**
     * Sets the properties for internationalRB when activated
     * Enables internationalCB and disables the others
     */
    @FXML
    private void internationalRBClick() {
        instateCB.setDisable(true);
        instateCB.setSelected(false);
        instateTF.setDisable(true);
        outstateCB.setDisable(true);
        outstateCB.setSelected(false);
        internationalCB.setDisable(false);
    }

    /**
     * Sets the properties for addButton when activated
     * Used to add students to the student list
     * Reports all warnings and errors present as well as whether or not the student could be added to the list
     */
    @FXML
    private void add() {
        boolean blockStudentAdd = false;
        boolean isAdded = false;
        int cr = 0;
        int funds = 0;

        String fn = fnameTF.getText();
        String ln = lnameTF.getText();
        if (fn.equals("")) {
            outputTA.appendText(NO_FIRST_NAME); //reports no first name present
            blockStudentAdd = true;
        }
        if(ln.equals("")) {
            outputTA.appendText(NO_LAST_NAME); //reports no last name present
            blockStudentAdd = true;
        }

        String studentType = ((RadioButton) studentTypeRG.getSelectedToggle()).getText();

        String crs = creditsTF.getText();
        if (crs.equals("")) {
            outputTA.appendText(NO_CREDITS); //reports no number of credits specified
            if (studentType.equals(instateRB.getText()) && instateCB.isSelected()) {
                //checks if funds is specified and is a number if applicable
                try {
                    funds = Integer.parseInt(instateTF.getText());
                    if (funds < 0) {
                        outputTA.appendText(FUNDS_INVALID); //reports amount of funding is invalid
                        blockStudentAdd = true;
                    }
                } catch (NumberFormatException ex) {
                    if(instateTF.getText().equals("")) {
                        outputTA.appendText(NO_FUNDS); //reports no funding is specified
                    } else {
                        outputTA.appendText(FUNDS_NOT_NUMBER); //reports amount of funding specified is not a number
                    }
                }
            }
            //checks if student is already on the list
            isAdded = students.add(new Instate(fn, ln,0,0));
            if(isAdded) {
                students.remove(new Instate(fn, ln, 0, 0)); //student specified is new
            } else {
                outputTA.appendText(STUDENT_ALREADY_PRESENT); //reports student specified is already on the list
            }
            outputTA.appendText(ADD_FAILURE); //reports student not added
            return;
        }
        
        try {
            cr = Integer.parseInt(crs);
            if (studentType.equals(internationalRB.getText()) && cr < International.MIN_CREDIT_HOURS) {
                outputTA.appendText(CREDITS_INVALID_INTERNATIONAL); //reports invalid number of credits for an international student
                blockStudentAdd = true;
            } else if (cr <= 0) {
                outputTA.appendText(CREDITS_INVALID); //reports invalid number of credits
                blockStudentAdd = true;
            } else if (studentType.equals(instateRB.getText()) && instateCB.isSelected()) {
                //checks if funds is specified and is a number if applicable
                try {
                    funds = Integer.parseInt(instateTF.getText());
                    if (cr < Student.FULL_TIME_CREDITS) {
                        outputTA.appendText(PART_TIME_FUNDS_WARNING); //Warns user that part time students cannot receive funding
                    }
                    if (funds < 0) {
                        outputTA.appendText(FUNDS_INVALID); //reports amount of funding is invalid
                        blockStudentAdd = true;
                    }
                } catch (NumberFormatException ex) {
                    if (cr < Student.FULL_TIME_CREDITS) {
                        outputTA.appendText(PART_TIME_FUNDS_WARNING); //Warns user that part time students cannot receive funding
                    }
                    if(instateTF.getText().equals("")) {
                        outputTA.appendText(NO_FUNDS); //reports no funding is specified
                    } else {
                        outputTA.appendText(FUNDS_NOT_NUMBER); //reports amount of funding specified is not a number
                    }
                    blockStudentAdd = true;
                }
            }
        } catch (NumberFormatException ex) {
            outputTA.appendText(CREDITS_NOT_NUMBER); //reports credits specified is not a number
            if (studentType.equals(instateRB.getText()) && instateCB.isSelected()) {
                //checks if funds is specified and is a number if applicable
                try {
                    funds = Integer.parseInt(instateTF.getText());
                    if (funds < 0) {
                        outputTA.appendText(FUNDS_INVALID); //reports amount of funding is invalid
                    }
                } catch (NumberFormatException e) {
                    if(instateTF.getText().equals("")) {
                        outputTA.appendText(NO_FUNDS); //reports no funding is specified
                    } else {
                        outputTA.appendText(FUNDS_NOT_NUMBER); //reports amount of funding specified is not a number
                    }
                }
            }
            blockStudentAdd = true;
        }

        if (blockStudentAdd) { //if an error occurred blockStudentAdd is set to true
            isAdded = students.add(new Instate(fn, ln,0,0));
            if(isAdded) {
                students.remove(new Instate(fn, ln, 0, 0)); //student specified is new
            } else {
                outputTA.appendText(STUDENT_ALREADY_PRESENT); //reports student specified is already on the list
            }
            outputTA.appendText(ADD_FAILURE); //reports student not added
            return;
        }

        if(studentType.equals(instateRB.getText())) {
            isAdded = students.add(new Instate(fn, ln, cr, funds));
        } else if(studentType.equals(outstateRB.getText())) {
            isAdded = students.add(new Outstate(fn, ln, cr, outstateCB.isSelected()));
        } else if(studentType.equals(internationalRB.getText())) {
            isAdded = students.add(new International(fn, ln, cr, internationalCB.isSelected()));
        }

        if (isAdded) {
            outputTA.appendText(ADD_SUCCESS); //reports student successfully added
        } else {
            outputTA.appendText(STUDENT_ALREADY_PRESENT); //reports student specified is already on the list
            outputTA.appendText(ADD_FAILURE); //reports student not added
        }
    }

    /**
     * Sets the properties for removeButton when activated
     * Used to remove students from the student list
     * Reports all warnings and errors present as well as whether or not the student could be removed from the list
     */
    @FXML
    private void remove() {
        String fn = fnameTF.getText();
        String ln = lnameTF.getText();
        if (fn.equals("")) {
            outputTA.appendText(NO_FIRST_NAME); //reports no student first name specified
        }
        if(ln.equals("")) {
            outputTA.appendText(NO_LAST_NAME); //reports no student last name specified
        }

        if (students.remove(new Instate(fn, ln, 0, 0))) {
            outputTA.appendText(REMOVE_SUCCESS); //reports student successfully removed
        } else {
            outputTA.appendText(STUDENT_NOT_FOUND); //reports student specified not on list
            outputTA.appendText(REMOVE_FAILURE); //reports student specified could not be removed
        }
    }

    /**
     * Sets the properties for printButton when activated
     * Prints out all the information from the current students in the list
     */
    @FXML
    private void print() {
        outputTA.appendText(students.toString() + "\n");
    }
    
    /**
     * Sets the properties for instateCB when activated
     * Enables instateTF when selected, disables when unselected
     */
    @FXML
    private void changeFundingDisable() {
        if(!instateCB.isSelected()) {
            instateTF.setDisable(true);
        } else {
            instateTF.setDisable(false);
        }
    }
}